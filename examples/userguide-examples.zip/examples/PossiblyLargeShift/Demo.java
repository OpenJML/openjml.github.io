public class Demo {
  public static void main(String ... args) {
    test(100);
  }
  public static int test(int i) {
    return 1 << i;
  }
}
