public class Demo {

  public int count;

  //@ public initially count > 0;

}
