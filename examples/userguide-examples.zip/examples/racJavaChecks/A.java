public class A {

  public static void main(String ... args) {
      int i = args.length;
      int j = i/(i-i);
  }

}
