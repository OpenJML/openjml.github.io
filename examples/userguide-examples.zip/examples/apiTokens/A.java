public class A {
   // simple comment

   //@ public invariant true;

}
