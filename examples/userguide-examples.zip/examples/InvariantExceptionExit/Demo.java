public class Demo {
  public static void main(String ... args) {
    try { test(); } catch (Exception e) {}
    i = 0;
  }
  public static int i = 0;
  //@ public static invariant i == 0;
  public static void test() {
    i = 1;
    throw new RuntimeException();
  }
}
