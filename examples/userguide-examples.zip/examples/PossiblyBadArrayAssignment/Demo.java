public class Demo {
  public static void test() {
    Object[] o = new Integer[10];
    o[0] = "abc";
  }
  public static void main(String ... args) { test(); }
}
