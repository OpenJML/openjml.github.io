public class Demo {
    public static void test() {
        //@ check \elemtype(\type(Object)) == \type(boolean);
    }
}
