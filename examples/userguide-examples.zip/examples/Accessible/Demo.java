public class Demo {

  public int i, j;

  //@ reads i;
  //@ pure
  public int mok() {
    return i;
  }

  //@ reads \nothing;
  public int mbad() {
    return i;
  }

  //@ reads j;
  public int mbad2() {
    return mok();
  }
}
