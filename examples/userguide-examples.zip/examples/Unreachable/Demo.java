public class Demo {
  public static void main(String ... args) {
    if (args.length > 0) {
      //@ unreachable
    }
  }
}
