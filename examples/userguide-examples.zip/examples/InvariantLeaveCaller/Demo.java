public class Demo {
  public int i;
  //@ public invariant i >= 0;
  public void test() {
    i = -1;
    test1();
  }
  public void test1() {}
}
