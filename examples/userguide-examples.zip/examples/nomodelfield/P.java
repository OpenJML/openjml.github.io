public class P {

//@ model public static int i;
//@ static represents i = 10;

}
