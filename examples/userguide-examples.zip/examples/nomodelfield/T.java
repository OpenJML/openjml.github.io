public class T extends P {

  public static void main(String... args) {
    //@ assert i == 11;
  }
}
