public class A {
  public static void main(String ... args) {
    //@ assert false;
  }
}
