public class B {
  //@ assert 0; // ERROR
}
