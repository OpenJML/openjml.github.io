public class Demo {
  public static void main(String ... args) { /*@ nullable */ Integer i = null; int k = (int)i; }
}
