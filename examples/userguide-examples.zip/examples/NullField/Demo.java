public class Demo {
  Object o;
  public Demo() {}
}
