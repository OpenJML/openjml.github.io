public class Demo {

  //@   requires i <= 0;
  //@ also
  //@   requires i >= 0;
  //@ behaviors disjoint;
  public void m(int i) {}

}
