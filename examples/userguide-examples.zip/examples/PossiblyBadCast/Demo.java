public class Demo {
  public static void main (String ... args) {
    Object o = "abc";
    Integer i = (Integer)o;
  }
}
