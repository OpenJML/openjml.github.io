public class Demo {
  //@ model public int modelField;

  public static void main(String... args) { 
     Demo d = new Demo();
     //@ show d.modelField;
  }
}
