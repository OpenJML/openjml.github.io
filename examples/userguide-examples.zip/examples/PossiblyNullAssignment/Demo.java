public class Demo {
  static Integer i;
  public static void main(String ... args) { i = null; }
}
