public class Demo {

  //@ model public \datagroup g;
  public int i; //@ in g;

  //@ assigns g;
  public void m() {
    i = 0;
  }
}
