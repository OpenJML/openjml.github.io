public class Demo {

  //@   requires i < 0;
  //@ also
  //@   requires i > 0;
  //@ behaviors complete;
  public void m(int i) {}

}
